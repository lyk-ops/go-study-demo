// +k8s:deepcopy-gen=package
// +groupName=cloud.waibizi.com

package v1